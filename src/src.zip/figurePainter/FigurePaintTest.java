package figurePainter;

public class FigurePaintTest {
    public static void main(String[] args) {
        FigurePaint figurePaint=new FigurePaint();
        figurePaint.figureOne(5,'*');
        figurePaint.figureTwo(5,'+');
        figurePaint.figureThree(4,"? ");
        figurePaint.figureFour(4,"!");
        figurePaint.figureFive(4,'*');
    }
}

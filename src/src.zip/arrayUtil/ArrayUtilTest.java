package arrayUtil;

import arrayUtil.ArrayUtil;

public class ArrayUtilTest {
    public static void main(String[] args) {
        ArrayUtil arrayUtil=new ArrayUtil();
        int arr[] = {10, 51, 2, 67, 24, 15, 94, 35, 45, 75};
        arrayUtil.printEvens(arr);
        arrayUtil.printOdds(arr);
        arrayUtil.calculateOddsCount(arr);
        arrayUtil.calculateEvensCount(arr);
        double arrNew[] = {1, 2, 3, 4, 5, 6, 7, 8, 9,};
        arrayUtil.findAverage(arrNew);
        arrayUtil.maxNumber(arr);
        arrayUtil.minNumber(arr);

    }
}

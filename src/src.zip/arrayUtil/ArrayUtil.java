package arrayUtil;

import classWork1.Array;

public class ArrayUtil {
    //        Task is to find the average of the following numbers
    public void findAverage(double[] numbers) {
        double arrNew[] = numbers;
        double average = 0;
        for (int i = 1; i < arrNew.length; i++)

        {
            average += arrNew[i];
        }
        System.out.println("The average number is: " + average / arrNew.length);
    }
    //        Task is to find the biggest number
    public void maxNumber(int[] number) {
        int arr[] = number;
        int result = arr[0];
        for (int k = 1; k < arr.length; k++) {
            if (result < arr[k]) {
                result = arr[k];
            }
        }
        System.out.println("The biggest number is " + result);
    }
    //        Task is to find the smallest num
    public void minNumber(int[] number) {
        int sum = number[0];
        for (int j = 0; j < number.length; j++) {
            if (sum > number[j]) {
                sum = number[j];
            }
        }
        System.out.println("The smallest number is " + sum);
    }

    //Task is to find all odd numbers
    public  void printOdds(int[] numbers) {
        System.out.println("The odd numbers are:");
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 1) {
                System.out.print(" " + numbers[i]);
            }
        }
        System.out.println();
    }

    //Task is to find all evens
    public void printEvens(int[] numbers) {
        System.out.println("The even numbers are:");
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 0)

                System.out.print(" " + numbers[i]);

        }
        System.out.println(" ");
    }

    //Task is to calculate the count of odds
    public void calculateOddsCount(int[] numbers) {
        int countOdds = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 1) {
                countOdds++;
            }
        }
        System.out.println("There are " + countOdds + " odds ");
    }

    //    task is to calculate the count of evens
    public void calculateEvensCount(int[] numbers) {
        int countEvens = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 0) {
                countEvens++;
            }
        }
        System.out.println("There are " + countEvens + " evens");
    }


}

